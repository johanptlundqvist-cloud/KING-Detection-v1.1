
package se.king.detection

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.*

data class Point(val x: Float, val y: Float, val field: Float = 0f)

class MainActivity : Activity(), SensorEventListener {
    private val bg = Color.rgb(5, 12, 27)
    private val cyan = Color.rgb(38, 216, 255)
    private val gold = Color.rgb(255, 197, 68)
    private val sensors by lazy { getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    private var stepSensor: Sensor? = null
    private var rotationSensor: Sensor? = null
    private var accelSensor: Sensor? = null
    private var magneticSensor: Sensor? = null
    private var heading = 0f
    private var field = 0f
    private var stride = .68f
    private var running = false
    private var following = false
    private var current = mutableListOf(Point(0f, 0f))
    private var saved = mutableListOf<Point>()
    private var lastStepTime = 0L
    private var smoothMagnitude = 9.81f
    private var peakArmed = false
    private var accel = FloatArray(3)
    private var magnet = FloatArray(3)
    private var hasAccel = false
    private var hasMagnet = false
    private lateinit var route: RouteView
    private lateinit var status: TextView
    private lateinit var metrics: TextView
    private lateinit var startButton: Button
    private lateinit var followButton: Button
    private lateinit var intro: LinearLayout
    private lateinit var dashboard: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        stepSensor = sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        rotationSensor = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        accelSensor = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magneticSensor = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        restore()
        makeUI()
        registerSensors()
        requestStepPermission()
    }

    private fun label(text: String, size: Float = 15f, color: Int = Color.WHITE): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER_VERTICAL }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(20, 68, 101))
            setOnClickListener { action() }
        }

    private fun makeUI() {
        val outer = FrameLayout(this).apply { setBackgroundColor(bg) }
        setContentView(outer)
        dashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }
        outer.addView(dashboard, FrameLayout.LayoutParams(-1, -1))
        dashboard.addView(label("♛  KING  DETECTION", 23f, gold))
        dashboard.addView(label("SENSORFUSION  /  INOMHUSKARTLÄGGNING", 10f, cyan))
        status = label("", 12f, cyan)
        dashboard.addView(status)
        route = RouteView(this)
        dashboard.addView(route, LinearLayout.LayoutParams(-1, 0, 1f))
        metrics = label("", 13f)
        dashboard.addView(metrics)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dashboard.addView(actions)
        val row1 = LinearLayout(this)
        actions.addView(row1)
        startButton = button("▶ Kartlägg") { toggleMapping() }
        row1.addView(startButton, LinearLayout.LayoutParams(0, dp(55), 1f))
        followButton = button("⌖ Följ spår") { toggleFollow() }
        row1.addView(followButton, LinearLayout.LayoutParams(0, dp(55), 1f))
        val row2 = LinearLayout(this)
        actions.addView(row2)
        row2.addView(button("▣ Spara rutt") { saveRoute() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        row2.addView(button("↺ Ny rutt") { newRoute() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        row2.addView(button("⚙ Inställningar") { settings() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        updateUI()
        intro = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(18), dp(22), dp(18))
            setBackgroundColor(bg)
        }
        outer.addView(intro, FrameLayout.LayoutParams(-1, -1))
        val image = ImageView(this).apply {
            setImageResource(se.king.detection.R.mipmap.app_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        intro.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        intro.addView(label("INITIERAR DETEKTOR", 19f, cyan))
        val detail = label(sensorSummary(), 13f)
        intro.addView(detail)
        intro.addView(label("Kalibrera kompassen genom att röra telefonen i en åtta vid behov.", 12f))
        intro.addView(button("◉ AKTIVERA DETEKTOR") {
            intro.visibility = View.GONE
            updateUI()
        }, LinearLayout.LayoutParams(-1, dp(66)))
    }

    private fun sensorSummary(): String =
        "Steg: ${if (stepSensor != null) "stegsensor" else if (accelSensor != null) "accelerometer (uppskattning)" else "saknas"}\n" +
        "Riktning: ${if (rotationSensor != null) "rotationssensor" else if (accelSensor != null && magneticSensor != null) "kompass" else "saknas"}\n" +
        "Magnetfält: ${if (magneticSensor != null) "tillgängligt" else "saknas"}"

    private fun requestStepPermission() {
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 100)
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) { registerSensors(); updateUI() }
    }
    private fun registerSensors() {
        sensors.unregisterListener(this)
        rotationSensor?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        accelSensor?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        magneticSensor?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        if (Build.VERSION.SDK_INT < 29 ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED) {
            stepSensor?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
    }
    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_STEP_DETECTOR -> if (event.values[0] > 0f) recordStep()
            Sensor.TYPE_ROTATION_VECTOR -> {
                val matrix = FloatArray(9)
                val angles = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(matrix, event.values)
                SensorManager.getOrientation(matrix, angles)
                heading = ((Math.toDegrees(angles[0].toDouble()).toFloat() + 360f) % 360f)
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                field = sqrt(event.values.take(3).sumOf { (it * it).toDouble() }).toFloat()
                event.values.copyInto(magnet, 0, 0, 3)
                hasMagnet = true
            }
            Sensor.TYPE_ACCELEROMETER -> {
                event.values.copyInto(accel, 0, 0, 3)
                hasAccel = true
                // Use accelerometer steps ONLY if the hardware step detector is unavailable.
                if (stepSensor == null) {
                    val magnitude = sqrt(accel.sumOf { (it * it).toDouble() }).toFloat()
                    smoothMagnitude = .85f * smoothMagnitude + .15f * magnitude
                    val delta = magnitude - smoothMagnitude
                    if (delta < .25f) peakArmed = true
                    if (peakArmed && delta > 1.65f) {
                        peakArmed = false
                        recordStep()
                    }
                }
            }
        }
        if (rotationSensor == null && hasAccel && hasMagnet) {
            val matrix = FloatArray(9)
            if (SensorManager.getRotationMatrix(matrix, null, accel, magnet)) {
                val angles = FloatArray(3)
                SensorManager.getOrientation(matrix, angles)
                heading = ((Math.toDegrees(angles[0].toDouble()).toFloat() + 360f) % 360f)
            }
        }
        if (::metrics.isInitialized) updateUI()
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun recordStep() {
        if (!running) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastStepTime < 270) return
        lastStepTime = now
        val last = current.last()
        val rad = Math.toRadians(heading.toDouble())
        current.add(Point(last.x + (stride * sin(rad)).toFloat(),
                          last.y - (stride * cos(rad)).toFloat(), field))
        route.invalidate()
        updateUI()
    }
    private fun toggleMapping() {
        if (following) { following = false; running = false }
        running = !running
        updateUI()
    }
    private fun toggleFollow() {
        if (saved.size < 2) {
            Toast.makeText(this, "Spara först en rutt med minst ett steg.", Toast.LENGTH_LONG).show()
            return
        }
        if (!following) {
            current = mutableListOf(Point(0f, 0f))
            following = true
            running = true
        } else {
            following = false
            running = false
        }
        updateUI()
    }
    private fun saveRoute() {
        if (current.size < 2) {
            Toast.makeText(this, "Ingen gångrutt att spara ännu.", Toast.LENGTH_SHORT).show()
            return
        }
        saved = current.toMutableList()
        running = false
        following = false
        val array = JSONArray()
        saved.forEach { array.put(JSONObject().put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("field", it.field.toDouble())) }
        getSharedPreferences("routes", MODE_PRIVATE).edit().putString("last", array.toString()).apply()
        Toast.makeText(this, "Rutten sparad lokalt", Toast.LENGTH_SHORT).show()
        updateUI()
    }
    private fun restore() {
        val raw = getSharedPreferences("routes", MODE_PRIVATE).getString("last", null) ?: return
        try {
            val a = JSONArray(raw)
            saved = (0 until a.length()).map {
                val p = a.getJSONObject(it)
                Point(p.getDouble("x").toFloat(), p.getDouble("y").toFloat(), p.optDouble("field").toFloat())
            }.toMutableList()
        } catch (_: Exception) { saved.clear() }
    }
    private fun newRoute() {
        running = false
        following = false
        current = mutableListOf(Point(0f, 0f))
        updateUI()
    }
    private fun settings() {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(String.format(Locale.US, "%.2f", stride))
            selectAll()
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Steglängd i meter (0,3–1,5)")
            .setView(input)
            .setPositiveButton("Spara") { _, _ ->
                val n = input.text.toString().replace(',', '.').toFloatOrNull()
                if (n != null && n in .3f..1.5f) stride = n
                else Toast.makeText(this, "Ogiltig steglängd", Toast.LENGTH_SHORT).show()
                updateUI()
            }.setNegativeButton("Avbryt", null).show()
    }
    private fun updateUI() {
        if (!::metrics.isInitialized) return
        val steps = (current.size - 1).coerceAtLeast(0)
        val savedSteps = (saved.size - 1).coerceAtLeast(0)
        val permissionMissing = Build.VERSION.SDK_INT >= 29 && stepSensor != null &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
        status.text = when {
            permissionMissing -> "⚠ Ge behörighet för fysisk aktivitet"
            following && running -> "● FÖLJ SPÅR  •  jämför blå och gul rutt"
            running -> "● KARTLÄGGNING PÅGÅR"
            else -> "○ REDO  •  ${sensorSummary().replace("\n", "  •  ")}"
        }
        val distance = steps * stride
        metrics.text = "STEG $steps   •   ${"%.1f".format(Locale.getDefault(), distance)} m   •   ${heading.roundToInt()}°\n" +
            "MAGNETFÄLT ${"%.1f".format(Locale.getDefault(), field)} µT   •   SPARAT $savedSteps steg"
        startButton.text = if (running && !following) "Ⅱ Pausa" else "▶ Kartlägg"
        followButton.text = if (following) "■ Avsluta följ" else "⌖ Följ spår"
        route.invalidate()
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).roundToInt()
    override fun onPause() {
        super.onPause()
        sensors.unregisterListener(this)
        if (running) { running = false; if (::metrics.isInitialized) updateUI() }
    }
    override fun onResume() { super.onResume(); registerSensors() }

    inner class RouteView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            canvas.drawColor(Color.rgb(7, 22, 42))
            paint.color = Color.rgb(20, 53, 74); paint.strokeWidth = 1f
            val grid = dp(28).toFloat()
            var x = 0f
            while (x < w) { canvas.drawLine(x, 0f, x, h, paint); x += grid }
            var y = 0f
            while (y < h) { canvas.drawLine(0f, y, w, y, paint); y += grid }
            val all = current + saved
            val minX = all.minOfOrNull { it.x } ?: 0f
            val maxX = all.maxOfOrNull { it.x } ?: 0f
            val minY = all.minOfOrNull { it.y } ?: 0f
            val maxY = all.maxOfOrNull { it.y } ?: 0f
            val extent = max(maxX - minX, maxY - minY).coerceAtLeast(8f)
            val scale = (min(w, h) * .78f) / extent
            val midX = (maxX + minX) / 2
            val midY = (maxY + minY) / 2
            fun px(p: Point) = w / 2 + (p.x - midX) * scale
            fun py(p: Point) = h / 2 + (p.y - midY) * scale
            fun drawPath(points: List<Point>, color: Int) {
                if (points.isEmpty()) return
                val path = Path()
                points.forEachIndexed { i, p -> if (i == 0) path.moveTo(px(p), py(p)) else path.lineTo(px(p), py(p)) }
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(4).toFloat()
                paint.strokeCap = Paint.Cap.ROUND; paint.strokeJoin = Paint.Join.ROUND
                paint.color = color
                canvas.drawPath(path, paint)
                paint.style = Paint.Style.FILL
                paint.color = color
                canvas.drawCircle(px(points.last()), py(points.last()), dp(6).toFloat(), paint)
            }
            drawPath(saved, gold)
            drawPath(current, cyan)
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            canvas.drawCircle(px(Point(0f, 0f)), py(Point(0f, 0f)), dp(5).toFloat(), paint)
            // Relative magnetic spikes: visually mark measurements above a conservative threshold.
            current.filter { it.field > 80f }.forEach {
                paint.color = Color.rgb(255, 75, 85)
                canvas.drawCircle(px(it), py(it), dp(5).toFloat(), paint)
            }
            paint.typeface = Typeface.create("sans-serif-monospace", Typeface.BOLD)
            paint.textSize = dp(12).toFloat()
            paint.color = cyan
            canvas.drawText("LIVE ROUTE", dp(12).toFloat(), dp(24).toFloat(), paint)
            paint.color = gold
            canvas.drawText("— SAVED", dp(12).toFloat(), dp(43).toFloat(), paint)
            paint.color = Color.LTGRAY
            canvas.drawText("N ↑", w - dp(44), dp(24).toFloat(), paint)
            if (current.size == 1 && saved.size < 2) {
                paint.color = Color.LTGRAY
                paint.textAlign = Paint.Align.CENTER
                canvas.drawText("Gå med telefonen för att rita rutten", w / 2, h / 2 + dp(32), paint)
                paint.textAlign = Paint.Align.LEFT
            }
        }
    }
}
