# KING Detection — Android source project

A new native Android implementation (Kotlin) built from the requirements discussed in chat.

## Features
- KING Detection branded splash screen with manual entry into detector mode
- Dark high-tech dashboard, grid map, neon routes, clear action buttons
- Step detection using Android `TYPE_STEP_DETECTOR`, or accelerometer fallback when unavailable
- Direction using rotation vector or accelerometer + magnetometer fallback
- Live route plotting; pause/resume, reset and local save
- Follow route: previous path in gold, current route in blue
- Magnetic field reading and red marks for readings above 80 µT (NOT proof of a phone)
- Step-length setting and sensor/permission diagnostics
- No internet permission or data upload

## Important limitations
Indoor dead reckoning is approximate; compass and step estimates drift, especially near metal.
The app cannot reliably identify concealed mobile phones from magnetometer readings.
Follow route is a visual comparison, not turn-by-turn indoor navigation.
Splash screen shows sensor availability; it does NOT pretend to perform calibration.
The app pauses route recording on backgrounding.

## Build in GitHub Actions
1. Upload the project files into a new GitHub repository (preserve folder structure).
2. Open Actions > Build Android APK > Run workflow.
3. Download the APK from the workflow artifacts.

Or open this folder in Android Studio and Build > Build APK(s).

## Testing needed on real device
Grant Physical activity permission when asked; walk 20+ steps while Kartlägg is active.
Check heading, live line, save, new route, follow route and route persistence.
Hardware sensor accuracy and Android UI behavior are not verified in this environment.
